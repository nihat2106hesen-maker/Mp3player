package com.carro.player

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

object Engine {
    init { System.loadLibrary("carro") }
    external fun load(fd: Int): Boolean
    external fun play()
    external fun pause()
    external fun seek(ms: Long)
    external fun pos(): Long
    external fun dur(): Long
    external fun finished(): Boolean
    external fun spectrum(a: FloatArray)
    external fun release()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
    override fun onDestroy() { Engine.release(); super.onDestroy() }
}

private val AMBER = Color(0xFFFFA000)
private val DIM = Color(0xFF2E2000)
private val MONO = FontFamily.Monospace
private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

@Composable
fun Key(t: String, on: () -> Unit) {
    Box(
        Modifier.size(72.dp, 52.dp).clip(RoundedCornerShape(8.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3C3C3C), Color(0xFF101010))))
            .border(1.dp, Color(0xFF606060), RoundedCornerShape(8.dp)).clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) { Text(t, color = AMBER, fontSize = 18.sp, fontFamily = MONO) }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var uris by remember { mutableStateOf(listOf<Uri>()) }
    var names by remember { mutableStateOf(listOf<String>()) }
    var cur by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var drag by remember { mutableStateOf<Float?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val bars = remember { FloatArray(16) }
    val raw = remember { FloatArray(16) }

    fun playAt(i: Int) {
        if (uris.isEmpty()) return
        val k = (i + uris.size) % uris.size
        val fd = ctx.contentResolver.openFileDescriptor(uris[k], "r")?.detachFd() ?: return
        if (Engine.load(fd)) { cur = k; dur = Engine.dur(); Engine.play(); playing = true } else playing = false
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { u ->
        if (u.isNotEmpty()) {
            uris = u
            names = u.map { x ->
                ctx.contentResolver.query(x, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "Track"
            }
            playAt(0)
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(33)
            if (cur >= 0) {
                pos = Engine.pos()
                Engine.spectrum(raw)
                for (i in 0 until 16) bars[i] = maxOf(raw[i], bars[i] * 0.85f)
                tick++
                if (playing && Engine.finished()) playAt(cur + 1)
            }
        }
    }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF222222), Color.Black)))
            .systemBarsPadding().padding(12.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF080500))
                .border(2.dp, AMBER.copy(alpha = 0.5f), RoundedCornerShape(10.dp)).padding(14.dp)
        ) {
            Text(
                if (cur >= 0) "%02d %s".format(cur + 1, names[cur]) else "NO FILES - TAP OPEN",
                color = AMBER, fontFamily = MONO, fontSize = 17.sp, maxLines = 1
            )
            Text("${fmt(pos)} / ${fmt(dur)}", color = AMBER.copy(alpha = 0.7f), fontFamily = MONO, fontSize = 13.sp)
            Canvas(Modifier.fillMaxWidth().height(96.dp).padding(top = 8.dp)) {
                val t = tick
                val w = size.width / 16
                val h = size.height / 10
                for (i in 0 until 16) {
                    val lit = (bars[i] * 10).toInt()
                    for (s in 0 until 10)
                        drawRect(
                            if (s < lit) AMBER else DIM,
                            Offset(i * w + 2f, size.height - (s + 1) * h + 1f),
                            Size(w - 4f, h - 2f)
                        )
                }
            }
            Slider(
                value = drag ?: (if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { Engine.seek((it * dur).toLong()) }; drag = null },
                colors = SliderDefaults.colors(thumbColor = AMBER, activeTrackColor = AMBER, inactiveTrackColor = DIM)
            )
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Key("◄◄") { playAt(cur - 1) }
            Key(if (playing) "▌▌" else "►") {
                if (cur >= 0) { if (playing) Engine.pause() else Engine.play(); playing = !playing }
            }
            Key("►►") { playAt(cur + 1) }
            Key("OPEN") { pick.launch(arrayOf("audio/*")) }
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(names) { i, n ->
                Text(
                    "%02d %s".format(i + 1, n),
                    color = if (i == cur) AMBER else Color.Gray, fontFamily = MONO, maxLines = 1,
                    modifier = Modifier.fillMaxWidth().clickable { playAt(i) }.padding(8.dp)
                )
            }
        }
    }
}
