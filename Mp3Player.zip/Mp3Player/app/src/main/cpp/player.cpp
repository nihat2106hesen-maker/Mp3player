// C++ audio engine: MediaExtractor + MediaCodec (decode) -> AAudio (output) + Goertzel spectrum
#include <jni.h>
#include <aaudio/AAudio.h>
#include <media/NdkMediaExtractor.h>
#include <media/NdkMediaCodec.h>
#include <media/NdkMediaFormat.h>
#include <atomic>
#include <cmath>
#include <cstring>
#include <deque>
#include <mutex>
#include <thread>
#include <unistd.h>

static AMediaExtractor* ex; static AMediaCodec* codec; static AAudioStream* out;
static std::thread th; static std::mutex mu; static std::deque<int16_t> q;
static std::atomic<bool> run{false}, playing{false}, done{false}, seekReq{false};
static std::atomic<int64_t> seekUs{0}, baseUs{0}, played{0}, durUs{0};
static int sr = 44100, ch = 2;
static int16_t ring[512]; static std::atomic<uint32_t> wp{0};

static aaudio_data_callback_result_t cb(AAudioStream*, void*, void* data, int32_t frames) {
    auto* o = static_cast<int16_t*>(data);
    int need = frames * ch, i = 0;
    if (playing) {
        std::unique_lock<std::mutex> l(mu, std::try_to_lock);
        if (l.owns_lock()) for (; i < need && !q.empty(); i++) { o[i] = q.front(); q.pop_front(); }
    }
    played += i / ch;
    for (int j = i; j < need; j++) o[j] = 0;
    uint32_t w = wp;
    for (int f = 0; f < frames; f++) ring[w++ & 511] = (ch > 1) ? (o[f * ch] + o[f * ch + 1]) / 2 : o[f];
    wp = w;
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}

static void decodeLoop() {
    bool inEos = false, outEos = false;
    AMediaCodecBufferInfo info;
    while (run && !outEos) {
        if (seekReq) {
            std::lock_guard<std::mutex> l(mu);
            q.clear();
            AMediaExtractor_seekTo(ex, seekUs, AMEDIAEXTRACTOR_SEEK_CLOSEST_SYNC);
            AMediaCodec_flush(codec);
            inEos = false; baseUs = seekUs.load(); played = 0; seekReq = false;
        }
        size_t n; { std::lock_guard<std::mutex> l(mu); n = q.size(); }
        if (n > (size_t)sr * ch) { usleep(10000); continue; }
        if (!inEos) {
            ssize_t i = AMediaCodec_dequeueInputBuffer(codec, 2000);
            if (i >= 0) {
                size_t sz; uint8_t* b = AMediaCodec_getInputBuffer(codec, i, &sz);
                ssize_t len = AMediaExtractor_readSampleData(ex, b, sz);
                if (len < 0) {
                    AMediaCodec_queueInputBuffer(codec, i, 0, 0, 0, AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM);
                    inEos = true;
                } else {
                    AMediaCodec_queueInputBuffer(codec, i, 0, len, AMediaExtractor_getSampleTime(ex), 0);
                    AMediaExtractor_advance(ex);
                }
            }
        }
        ssize_t o = AMediaCodec_dequeueOutputBuffer(codec, &info, 2000);
        if (o >= 0) {
            size_t sz; uint8_t* b = AMediaCodec_getOutputBuffer(codec, o, &sz);
            if (info.size > 0) {
                auto* p = reinterpret_cast<int16_t*>(b + info.offset);
                std::lock_guard<std::mutex> l(mu);
                q.insert(q.end(), p, p + info.size / 2);
            }
            AMediaCodec_releaseOutputBuffer(codec, o, false);
            if (info.flags & AMEDIACODEC_BUFFER_FLAG_END_OF_STREAM) outEos = true;
        }
    }
    while (run) { { std::lock_guard<std::mutex> l(mu); if (q.empty()) break; } usleep(20000); }
    if (run) done = true;
}

static void stopAll() {
    run = false;
    if (out) { AAudioStream_requestStop(out); AAudioStream_close(out); out = nullptr; }
    if (th.joinable()) th.join();
    if (codec) { AMediaCodec_stop(codec); AMediaCodec_delete(codec); codec = nullptr; }
    if (ex) { AMediaExtractor_delete(ex); ex = nullptr; }
    std::lock_guard<std::mutex> l(mu); q.clear();
}

#define J(name) Java_com_carro_player_Engine_##name

extern "C" {
JNIEXPORT jboolean JNICALL J(load)(JNIEnv*, jobject, jint fd) {
    stopAll(); done = false;
    off_t len = lseek(fd, 0, SEEK_END); lseek(fd, 0, SEEK_SET);
    ex = AMediaExtractor_new();
    media_status_t st = AMediaExtractor_setDataSourceFd(ex, fd, 0, len);
    close(fd);
    if (st != AMEDIA_OK) return JNI_FALSE;
    AMediaFormat* f = nullptr; const char* mime = nullptr;
    int n = AMediaExtractor_getTrackCount(ex);
    for (int i = 0; i < n && !f; i++) {
        AMediaFormat* t = AMediaExtractor_getTrackFormat(ex, i);
        const char* m = nullptr;
        if (AMediaFormat_getString(t, AMEDIAFORMAT_KEY_MIME, &m) && !strncmp(m, "audio/", 6)) {
            f = t; mime = m; AMediaExtractor_selectTrack(ex, i);
        } else AMediaFormat_delete(t);
    }
    if (!f) return JNI_FALSE;
    int32_t s = 44100, c = 2; int64_t d = 0;
    AMediaFormat_getInt32(f, AMEDIAFORMAT_KEY_SAMPLE_RATE, &s);
    AMediaFormat_getInt32(f, AMEDIAFORMAT_KEY_CHANNEL_COUNT, &c);
    AMediaFormat_getInt64(f, AMEDIAFORMAT_KEY_DURATION, &d);
    sr = s; ch = c; durUs = d;
    codec = AMediaCodec_createDecoderByType(mime);
    AMediaCodec_configure(codec, f, nullptr, nullptr, 0);
    AMediaCodec_start(codec);
    AMediaFormat_delete(f);
    AAudioStreamBuilder* b; AAudio_createStreamBuilder(&b);
    AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setSampleRate(b, sr);
    AAudioStreamBuilder_setChannelCount(b, ch);
    AAudioStreamBuilder_setDataCallback(b, cb, nullptr);
    aaudio_result_t r = AAudioStreamBuilder_openStream(b, &out);
    AAudioStreamBuilder_delete(b);
    if (r != AAUDIO_OK) { out = nullptr; return JNI_FALSE; }
    baseUs = 0; played = 0; seekReq = false; playing = false; run = true;
    th = std::thread(decodeLoop);
    AAudioStream_requestStart(out);
    return JNI_TRUE;
}
JNIEXPORT void JNICALL J(play)(JNIEnv*, jobject) { playing = true; }
JNIEXPORT void JNICALL J(pause)(JNIEnv*, jobject) { playing = false; }
JNIEXPORT void JNICALL J(seek)(JNIEnv*, jobject, jlong ms) { seekUs = ms * 1000; seekReq = true; }
JNIEXPORT jlong JNICALL J(pos)(JNIEnv*, jobject) { return (jlong)((baseUs + played * 1000000LL / sr) / 1000); }
JNIEXPORT jlong JNICALL J(dur)(JNIEnv*, jobject) { return (jlong)(durUs / 1000); }
JNIEXPORT jboolean JNICALL J(finished)(JNIEnv*, jobject) { return done ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT void JNICALL J(release)(JNIEnv*, jobject) { stopAll(); }
JNIEXPORT void JNICALL J(spectrum)(JNIEnv* e, jobject, jfloatArray a) {
    float v[16], x[512]; uint32_t w = wp;
    for (int i = 0; i < 512; i++) x[i] = ring[(w + i) & 511] / 32768.f;
    for (int b = 0; b < 16; b++) {
        float f = 50.f * powf(1.45f, (float)b), k = f * 512 / sr;
        float c = 2 * cosf(2 * (float)M_PI * k / 512), s1 = 0, s2 = 0;
        for (int i = 0; i < 512; i++) { float s = x[i] + c * s1 - s2; s2 = s1; s1 = s; }
        float m = sqrtf(fmaxf(s1 * s1 + s2 * s2 - c * s1 * s2, 0.f)) / 256.f;
        v[b] = fminf(1.f, sqrtf(m) * 1.6f);
    }
    e->SetFloatArrayRegion(a, 0, 16, v);
}
}
